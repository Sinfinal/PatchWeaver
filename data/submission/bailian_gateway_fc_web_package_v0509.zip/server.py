"""HTTP custom-runtime entrypoint for PatchWeaver Bailian gateway.

This file is intentionally standard-library only so it can run in Aliyun
Function Compute custom runtime without an extra dependency install step.
"""

from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from bailian_gateway import invoke_gateway, openapi_schema


def _json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict[str, Any]) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Headers", "content-type, authorization, x-patchweaver-client")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


class PatchWeaverGatewayHandler(BaseHTTPRequestHandler):
    server_version = "PatchWeaverBailianGateway/1.0"

    def do_OPTIONS(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        _json_response(self, 200, {"ok": True})

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if self.path in ("/", "/healthz"):
            _json_response(self, 200, {"ok": True, "service": "patchweaver-bailian-gateway"})
            return
        if self.path.startswith("/openapi.json"):
            server_url = os.getenv("PATCHWEAVER_GATEWAY_PUBLIC_URL", "").rstrip("/") or "https://patchweaver-gateway.example.com"
            _json_response(self, 200, openapi_schema(server_url))
            return
        _json_response(self, 404, {"ok": False, "error": "not_found", "path": self.path})

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if self.path not in ("/gateway", "/api/v1/integrations/bailian/gateway"):
            _json_response(self, 404, {"ok": False, "error": "not_found", "path": self.path})
            return

        try:
            length = int(self.headers.get("content-length", "0") or "0")
            raw = self.rfile.read(length) if length > 0 else b"{}"
            event = json.loads(raw.decode("utf-8") or "{}")
        except Exception as exc:  # pragma: no cover - defensive boundary for FC runtime
            _json_response(self, 400, {"ok": False, "error": f"invalid_json: {exc}"})
            return

        if not isinstance(event, dict):
            _json_response(self, 400, {"ok": False, "error": "request body must be a JSON object"})
            return

        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {
                key: value
                for key, value in event.items()
                if key not in {"action", "dry_run", "payload"}
            }
        try:
            result = invoke_gateway(
                str(event.get("action") or "status"),
                payload,
                dry_run=bool(event.get("dry_run", True)),
            )
        except Exception as exc:  # pragma: no cover - keeps platform response structured
            _json_response(self, 500, {"ok": False, "error": str(exc)})
            return
        _json_response(self, 200, result)

    def log_message(self, format: str, *args: Any) -> None:
        # FC captures stdout/stderr; keep request logs terse and non-secret.
        print("%s - %s" % (self.address_string(), format % args))


def main() -> None:
    port = int(os.getenv("FC_SERVER_PORT") or os.getenv("PORT") or "9000")
    server = ThreadingHTTPServer(("0.0.0.0", port), PatchWeaverGatewayHandler)
    print(f"PatchWeaver Bailian gateway listening on 0.0.0.0:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
