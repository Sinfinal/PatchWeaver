# PatchWeaver Bailian FC Package

This package is intentionally small and uses only Python standard library modules.

## Function Entrypoint

- File: `index.py`
- Handler: `index.handler`

## Required Environment

- `PATCHWEAVER_API_BASE_URL`: PatchWeaver API base URL reachable from FC.
- `PATCHWEAVER_BAILIAN_API_KEY`: optional bearer token. Keep it in FC secrets or protected environment variables.
- `PATCHWEAVER_API_TIMEOUT_SECONDS`: optional HTTP timeout.

## Safe Smoke Test Payload

```json
{
  "action": "status",
  "payload": {
    "task_id": "demo-task"
  },
  "dry_run": true
}
```

Keep `dry_run=true` for first console validation. Switch to `false` only after network access to PatchWeaver API is confirmed.

## OpenAPI Plugin Route

The package also includes `openapi.json` for Bailian plugin registration. If you deploy PatchWeaver API directly, the equivalent schema is available from:

```text
/api/v1/integrations/bailian/openapi.json?server_url=https://<reachable-host>/api/v1/integrations/bailian
```

The plugin operation calls:

```text
POST /api/v1/integrations/bailian/gateway
```
