"""Aliyun Function Compute entrypoint for PatchWeaver Bailian gateway."""

from __future__ import annotations

from bailian_gateway import fc_handler


def handler(event, context):
    """Function Compute handler."""

    return fc_handler(event, context)
