# PatchWeaver 任务报告

- 最终状态: failed

## 任务摘要
- task_id: judge-like-challenge14final-2026050920-26607
- cve_id: CVE-2024-26607
- target_kernel: 6.6.102-5.2.an23.x86_64
- profile_name: demo
- workspace_dir: workspaces/judge-like-challenge14final-2026050920-26607

## 尝试摘要
- 第 1 轮: failed (feature_not_enabled) / build_exec_status=not_run

## 分析结果
- semantic_card_path: workspaces/judge-like-challenge14final-2026050920-26607/analysis/semantic_card.json
- constraint_report_path: workspaces/judge-like-challenge14final-2026050920-26607/analysis/constraint_report.json
- patch_bundle_path: workspaces/judge-like-challenge14final-2026050920-26607/input/patch_bundle.json

## 构建结果
- latest_attempt_id: judge-like-challenge14final-2026050920-26607-A001
- latest_attempt_status: failed
- latest_failure_type: feature_not_enabled
- latest_build_exec_status: not_run
- latest_target_state: None
- build_log_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/build.log
- module_path: None
- rewritten_patch_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/rewrite/rewritten.patch

## 验证结果
- validation_report_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/artifacts/validation_report.json
- validation_matrix_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/artifacts/validation_matrix.json
- semantic_guard_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/artifacts/semantic_guard.json
- validation_status: pending
- validation_intensity: light
- semantic_guard_status: pending
- load_status: pending
- unload_status: pending
- smoke_status: pending
- selftest_status: pending
- regression_status: skipped

## 闭环状态
- closure_type: failure
- closure_status: ready
- failure_replay_ready: True
- success_replay_ready: False
- validation_status: pending
- missing_success_evidence: []
- recommended_replay_files: ['workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/harness_trace.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/failure_record.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/build.log', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/artifacts/validation_report.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/failover.jsonl']

## 回放索引
- trace_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/harness_trace.json
- failover_record_path: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/failover.jsonl
- evaluation_summary_path: workspaces/judge-like-challenge14final-2026050920-26607/reports/evaluation_summary.json
- recommended_replay_files: ['workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/harness_trace.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/failure_record.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/build.log', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/artifacts/validation_report.json', 'workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/failover.jsonl']

## Agent Decision Summary
- RepairIntent strategy: semantic_guard
- RepairIntent root_cause: sii902x_init 中存在空指针或对象有效性检查缺陷，补丁将条件 `sii902x->i2c->irq > 0` 调整为 `ret`。 依据：[ Upstream commit 08ac6f132dd77e40f786d8af51140c96c6d739c9 ]
- selected_recipe: semantic_guard_rewrite
- selected_strategy: unknown
- strategy_switched: True
- strategy_reason: 优先选择综合得分最高的候选，当前命中 semantic_guard_rewrite，排序得分 0.726
- failure_type: feature_not_enabled
- failure_summary: 目标内核配置未启用补丁涉及源码，已在 apply 预检查阶段提前识别
- agent_next_action: none

## 关键路径
- report_json: workspaces/judge-like-challenge14final-2026050920-26607/reports/report.json
- report_md: workspaces/judge-like-challenge14final-2026050920-26607/reports/report.md
- workspace_dir: workspaces/judge-like-challenge14final-2026050920-26607
- report_trace: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/trace/harness_trace.json
- report_build_log: workspaces/judge-like-challenge14final-2026050920-26607/attempts/001/logs/build.log

## 评测摘要
- total_attempts: 1
- built_attempts: 0
- failed_attempts: 1
- success_rate: 0.0
- average_attempt_no: 1.0
- latest_status: failed
- latest_failure_type: feature_not_enabled
- failure_breakdown: {'feature_not_enabled': 1}
- artifact_type_counts: {'task_context': 1, 'raw_patch': 1, 'normalized_patch': 1, 'patch_bundle': 1, 'source_evidence': 1, 'source_fetch_trace': 1, 'semantic_card': 1, 'semantic_card_enrichment': 1, 'repair_intent': 2, 'constraint_report': 1, 'analysis_bootstrap_manifest': 1, 'analysis_evidence_bundle': 1, 'analysis_context_bundle': 1, 'retrieval_skill_route': 1, 'retrieval_prompt_packet': 1, 'semantic_card_skill_route': 1, 'semantic_card_prompt_packet': 1, 'constraint_skill_route': 1, 'constraint_prompt_packet': 1, 'analysis_trace': 1, 'rewrite_bootstrap_manifest': 1, 'rewrite_evidence_bundle': 1, 'rewrite_context_bundle': 1, 'rewrite_skill_route': 1, 'rewrite_prompt_packet': 1, 'rewrite_plan': 1, 'planning_hints': 1, 'route_effectiveness': 1, 'rewritten_patch': 1, 'rewrite_reason': 1, 'transformation_trace': 1, 'apply_precheck': 1, 'semantic_guard_rewrite': 1, 'environment_check_log': 1, 'build_log': 1, 'build_summary': 1, 'failure_record': 1, 'failure_memory_snapshot': 1, 'recipe_memory_snapshot': 1, 'validate_log': 1, 'semantic_precheck': 1, 'semantic_guard': 1, 'validation_matrix': 1, 'selftest_log': 1, 'load_log': 1, 'unload_log': 1, 'smoke_log': 1, 'regression_log': 1, 'regression_summary': 1, 'validation_report': 1, 'validation_evidence_bundle': 1, 'validation_context_bundle': 1, 'validation_skill_route': 1, 'validation_prompt_packet': 1, 'attempt_state': 1, 'harness_trace': 1, 'failover_record': 1, 'failure_analysis_evidence_bundle': 1, 'failure_analysis_context_bundle': 1, 'failure_analysis_skill_route': 1, 'failure_analysis_prompt_packet': 1}

## 当前限制
- 最近一轮失败类型为 feature_not_enabled，仍需结合回放进一步排查

## 说明
- 当前共执行 1 轮尝试。
- 分析、归因和报告阶段按只读路径整理证据，改写与构建阶段走写入独占路径。
- 当前成功率为 0%，已归档产物类型 61 类。
- 最近一轮结果为 failed，失败类型为 feature_not_enabled。

## 下一步
- next_priority_layer: kernel_profile
- next_action: 当前验证内核未启用目标子系统；请切换内核配置或更换样例
